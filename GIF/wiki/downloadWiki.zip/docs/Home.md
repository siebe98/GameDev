XNA Gif Animation Library by Mahdi Khodadadi Fard.
XNA Gif Animation library is a flexible engine written in C# for XNA.

Features:
* Stand-alone library and small size (about 10 KB).
* Flexiblity and easy to use.